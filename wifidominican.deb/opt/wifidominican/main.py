#!/usr/bin/env python3
import sys
import os
sys.path.append(os.path.dirname(os.path.realpath(__file__)))

from core import scanner, deauth, handshake, cracker
from gui import main_window

def main():
    print("Bienvenido a WiFiDominican - Herramienta de auditoría WiFi")
    main_window.run()

if __name__ == "__main__":
    main()
