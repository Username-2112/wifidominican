import subprocess

def list_interfaces():
    """Devuelve una lista de interfaces inalámbricas disponibles."""
    try:
        result = subprocess.run(["iwconfig"], capture_output=True, text=True)
        interfaces = []
        for line in result.stdout.split("\n"):
            if "IEEE 802.11" in line:
                iface = line.split()[0]
                interfaces.append(iface)
        return interfaces
    except Exception as e:
        print(f"[✘] Error al listar interfaces: {e}")
        return []

def enable_monitor_mode(interface):
    """Activa el modo monitor en una interfaz específica."""
    try:
        subprocess.run(["airmon-ng", "check", "kill"])
        subprocess.run(["airmon-ng", "start", interface], check=True)
        print(f"[✔] Modo monitor activado en {interface}mon")
        return f"{interface}mon"
    except subprocess.CalledProcessError:
        print("[✘] Error al activar modo monitor.")
        return None

def disable_monitor_mode(interface_mon):
    """Desactiva el modo monitor y restaura la interfaz."""
    try:
        subprocess.run(["airmon-ng", "stop", interface_mon], check=True)
        subprocess.run(["service", "NetworkManager", "start"])
        print(f"[✔] Modo monitor desactivado en {interface_mon}")
        return True
    except subprocess.CalledProcessError:
        print("[✘] Error al desactivar modo monitor.")
        return False
