import tkinter as tk

def run():
    root = tk.Tk()
    root.title("WiFiDominican")
    tk.Label(root, text="Bienvenido a WiFiDominican", font=("Arial", 16)).pack(pady=20)
    tk.Button(root, text="Escanear Redes", width=20).pack(pady=5)
    tk.Button(root, text="Capturar Handshake", width=20).pack(pady=5)
    tk.Button(root, text="Deautenticar Cliente", width=20).pack(pady=5)
    tk.Button(root, text="Crackear Contraseña", width=20).pack(pady=5)
    tk.Button(root, text="Salir", command=root.quit, width=20).pack(pady=20)
    root.mainloop()
