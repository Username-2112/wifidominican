import subprocess
import os

def enable_monitor_mode(interface="wlan0"):
    try:
        subprocess.run(["airmon-ng", "start", interface], check=True)
        print(f"[✔] Modo monitor activado en {interface}mon")
        return f"{interface}mon"
    except subprocess.CalledProcessError:
        print("[✘] Error al activar modo monitor.")
        return None

def scan_networks(interface="wlan0mon"):
    try:
        print("[!] Escaneando redes WiFi. Presiona Ctrl+C para detener...")
        subprocess.run(["airodump-ng", interface])
    except KeyboardInterrupt:
        print("\n[✔] Escaneo detenido por el usuario.")
    except Exception as e:
        print(f"[✘] Error al escanear: {e}")
