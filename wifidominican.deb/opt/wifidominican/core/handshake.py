import subprocess
import time
import os

def capture_handshake(interface, bssid, channel, output_path="handshake"):
    """
    Captura un handshake de una red WiFi.

    - interface: interfaz en modo monitor (ej. wlan0mon)
    - bssid: MAC del AP (router objetivo)
    - channel: canal del AP
    - output_path: nombre del archivo de salida (.cap)
    """
    try:
        print(f"[!] Cambiando al canal {channel}...")
        subprocess.run(["iwconfig", interface, "channel", str(channel)], check=True)

        print(f"[✔] Escuchando para capturar handshake de {bssid}...")
        command = [
            "airodump-ng",
            "--bssid", bssid,
            "-c", str(channel),
            "-w", output_path,
            interface
        ]

        subprocess.run(command)
    except Exception as e:
        print(f"[✘] Error al capturar handshake: {e}")
